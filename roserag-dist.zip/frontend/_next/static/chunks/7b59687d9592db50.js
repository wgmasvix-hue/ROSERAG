__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f79c408287ec1d97.js",
  "static/chunks/turbopack-232a7fd8393d50e6.js"
])
