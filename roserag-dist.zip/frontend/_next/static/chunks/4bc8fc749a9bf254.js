__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/f79c408287ec1d97.js",
  "static/chunks/turbopack-6d8f5529d2d8b9b3.js"
])
