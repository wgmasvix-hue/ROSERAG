__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/d2dc8bfb08963caa.js",
  "static/chunks/turbopack-760714c3faed6ab3.js"
])
