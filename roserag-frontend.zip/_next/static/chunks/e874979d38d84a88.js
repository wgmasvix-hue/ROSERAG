__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d2dc8bfb08963caa.js",
  "static/chunks/turbopack-1a601dbc6f04dbb3.js"
])
